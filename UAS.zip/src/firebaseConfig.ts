// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDWlPziq9-zWXQDukVoN8i0Orf7Itk1TMQ",
  authDomain: "fir-11-8ab10.firebaseapp.com",
  projectId: "fir-11-8ab10",
  storageBucket: "fir-11-8ab10.appspot.com",
  messagingSenderId: "699397979091",
  appId: "1:699397979091:web:6843c2f7b49ea2276e4d26"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);